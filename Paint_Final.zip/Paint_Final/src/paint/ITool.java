/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paint;

import javafx.scene.canvas.GraphicsContext;

/**
 *
 * @author Débora
 */
public interface ITool 
{
    void onClick(double x, double y, GraphicsContext g);
    
    void onMouseDragged(double x, double y, GraphicsContext g);
}
