/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paint;

import javafx.scene.paint.Color;

/**
 *
 * @author Débora
 */
public class DrawParameters {
    
    private DrawParameters(){
    }
    
    private static DrawParameters instance;
    public static DrawParameters getInstance(){
        
        if(instance == null){
            instance = new DrawParameters();
        }
        return instance;
    }
    
    private Color strokeColor;
    private Color fillColor;
    private Color brushColor;
    private int  brushSize = 18;
    private boolean erase = false;

    /**
     * @return the strokeColor
     */
    public Color getStrokeColor() {
        return strokeColor;
    }

    /**
     * @param strokeColor the strokeColor to set
     */
    public void setStrokeColor(Color strokeColor) {
        this.strokeColor = strokeColor;
    }

    /**
     * @return the fillColor
     */
    public Color getFillColor() {
        return fillColor;
    }

    /**
     * @param fillColor the fillColor to set
     */
    public void setFillColor(Color fillColor) {
        this.fillColor = fillColor;
    }

    /**
     * @return the brushColor
     */
    public Color getBrushColor() {
        return brushColor;
    }

    /**
     * @param brushColor the brushColor to set
     */
    public void setBrushColor(Color brushColor) {
        this.brushColor = brushColor;
    }

    /**
     * @return the brushSize
     */
    public int getBrushSize() {
        return brushSize;
    }

    /**
     * @param brushSize the brushSize to set
     */
    public void setBrushSize(int brushSize) {
        this.brushSize = brushSize;
    }

    /**
     * @return the erase
     */
    public boolean isErase() {
        return erase;
    }

    /**
     * @param erase the erase to set
     */
    public void setErase(boolean erase) {
        this.erase = erase;
    }
}
