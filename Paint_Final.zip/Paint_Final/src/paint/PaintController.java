/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paint;


import javafx.application.Platform;
import javafx.embed.swing.SwingFXUtils;
import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javax.imageio.ImageIO;
import java.io.File;
import javafx.scene.Scene;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.effect.Reflection;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import java.util.Scanner;
import javafx.scene.control.Button;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
/**
 *
 * @author Débora
 */
public class PaintController
{
    @FXML
    private Canvas canvas;
    @FXML
    private ToggleButton btnRectangleTool;
    @FXML
    private ToggleButton btnEllipseTool;
    @FXML
    private ToggleButton btnTriangleTool;
    @FXML
    private ToggleButton btnBrushTool;
    @FXML
    private ToggleGroup ToolGroup;
    @FXML
    private ColorPicker cpkStroke;
    @FXML
    private ColorPicker cpkFill;
    @FXML
    private ColorPicker cpkBrush;
    @FXML
    private CheckBox ckbErase;
    @FXML
    private TextField txtBrushSize;
    
    private ITool activeTool;
    
    public void initialize()
    {
        GraphicsContext graphicsContext = canvas.getGraphicsContext2D();
        graphicsContext.setFill(Color.WHITE);
        graphicsContext.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());
        
        canvas.setOnMouseDragged(e ->
        {
            if (activeTool == null){
                return;
            }
            
            double x = e.getX();
            double y = e.getY();  
            activeTool.onMouseDragged(x, y, graphicsContext);
        });
        
        canvas.setOnMouseClicked(e -> 
        {
            if (activeTool == null){
                return;
            }
            
            double x = e.getX();
            double y = e.getY();
            activeTool.onClick(x, y, graphicsContext);
        });
        
        cpkStroke.setOnAction(e ->
        {
            DrawParameters.getInstance().setStrokeColor(cpkStroke.getValue());
        });
        
        cpkFill.setOnAction(e ->
        {
            DrawParameters.getInstance().setFillColor(cpkFill.getValue());
        });
        
        cpkBrush.setOnAction(e ->
        {
            DrawParameters.getInstance().setBrushColor(cpkBrush.getValue());
        });
        
        txtBrushSize.setOnAction(e ->
        {
            DrawParameters.getInstance().setBrushSize(Integer.parseInt(txtBrushSize.getText()));
        });
        
        ckbErase.setOnAction(e ->
        {
            DrawParameters.getInstance().setErase(ckbErase.isSelected());
        });
        
    }
    
    @FXML
    private void setActiveTool()
    {
        if(btnRectangleTool.isSelected())
        {
            activeTool = new RectangleTool();
        }
        else if(btnEllipseTool.isSelected())
        {
            activeTool = new EllipseTool();
        }
        else if(btnTriangleTool.isSelected())
        {
            activeTool = new PolygonTool();
        }
        else if(btnBrushTool.isSelected())
        {
            activeTool = new BrushTool();
        }
        else
        {
            activeTool = null;
        }
    }
    
    
    @FXML
    public void onSave(){
       try {
           Image snapshot = canvas.snapshot(null, null);
           
           ImageIO.write(SwingFXUtils.fromFXImage(snapshot,null), "png", new File("paint.png"));
       } catch (Exception e){
           System.out.println("Failed to save image: " + e);
       }
    }
    
    @FXML
    public void onExit(){
        Platform.exit();
    }
    
    
}
