/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paint;

import javafx.geometry.Point2D;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

/**
 *
 * @author Débora
 */
public class BrushTool implements ITool
{
   
    
    private void paintBrush(double x, double y, GraphicsContext g)
    {    
        int brushSize = DrawParameters.getInstance().getBrushSize();
        double brushX = x - brushSize / 2;
        double brushY = y - brushSize / 2;
       
        if(DrawParameters.getInstance().isErase() == true){
            g.setFill(Color.WHITE);
            g.fillRect(brushX, brushY, brushSize, brushSize);
        }else{
            g.setFill(DrawParameters.getInstance().getBrushColor());
            g.fillRect(brushX, brushY, brushSize, brushSize);
        } 
        
    }        
    
    @Override
    public void onMouseDragged(double x, double y, GraphicsContext g)
    {
        paintBrush(x, y, g);
    }
    
    @Override
    public void onClick(double x, double y, GraphicsContext g) 
    {
    }

    
}