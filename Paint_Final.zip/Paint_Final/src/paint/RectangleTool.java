/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paint;

import javafx.geometry.Point2D;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

/**
 *
 * @author Débora
 */
public class RectangleTool implements ITool
{
    private Point2D p1;
    private Point2D p2;
    
    
    
    private void insertRectangle(GraphicsContext g)
    {          
        double startX = p1.getX();
        double startY = p1.getY();
        
        double width = p2.getX() - startX;
        double height  = p2.getY() - startY;
        
        if(width < 0){
            startX = p2.getX();
            width *= -1;
        }
        if(height < 0){
            startY = p2.getY();
            height *= -1;
        }
                
        g.setFill(DrawParameters.getInstance().getFillColor());
        g.fillRect(startX, startY, width, height);
        g.setStroke(DrawParameters.getInstance().getStrokeColor());
        g.strokeRect(startX, startY, width, height);
    }
    
    private void resetRectangle()
    {
        p1 = null;
        p2 = null;
    }           
    
    @Override
    public void onClick(double x, double y, GraphicsContext g)
    {
        if(p1 == null){
            p1 = new Point2D(x,y);
        }
        else {
            p2 = new Point2D(x,y);
            insertRectangle(g);
            resetRectangle();
        }
    }
    
    @Override
    public void onMouseDragged(double x, double y, GraphicsContext g) 
    {
    }

   
}