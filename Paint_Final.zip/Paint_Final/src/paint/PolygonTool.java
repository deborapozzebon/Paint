/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paint;

import java.util.ArrayList;
import javafx.geometry.Point2D;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

/**
 *
 * @author Débora
 */
public class PolygonTool implements ITool
{    
    private Point2D p1;
    private Point2D p2;
    private Point2D p3;
    
  
    
    private void insertPolygon(GraphicsContext g)
    {          
        double[] listX = new double[3];
        listX[0]= p1.getX();
        listX[1]= p2.getX();
        listX[2]= p3.getX();
        
        double[] listY = new double[3];
        listY[0]= p1.getY();
        listY[1]= p2.getY();
        listY[2]= p3.getY();
        
        g.setFill(DrawParameters.getInstance().getFillColor());
        g.fillPolygon(listX, listY, 3);
        g.setStroke(DrawParameters.getInstance().getStrokeColor());
        g.strokePolygon(listX, listY, 3);
    }
    
    private void resetPolygon()
    {
        p1 = null;
        p2 = null;
        p3 = null;
    }           
    
    @Override
    public void onClick(double x, double y, GraphicsContext g)
    {
        if(p1 == null)
        {
            p1 = new Point2D(x,y);
        }
        else if (p2 == null)
        {
            p2 = new Point2D(x,y);
        }
        else 
        {
            p3 = new Point2D(x,y);
            insertPolygon(g);
            resetPolygon();
        }
    }
    
    @Override
    public void onMouseDragged(double x, double y, GraphicsContext g) 
    {
    }

    
}
